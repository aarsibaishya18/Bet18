class CasinoService {
    async launchGame(userId, gameId) {
        console.log(`[Mock Casino] Launching game ${gameId} for user ${userId}`);
        return { 
            success: true, 
            gameUrl: "https://mock-casino-provider.com/embed/" + gameId 
        };
    }

    async handleProviderWebhook(callbackData) {
        return { status: "OK" };
    }
}

module.exports = new CasinoService();
