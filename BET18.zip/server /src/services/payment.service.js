class PaymentService {
    async createDeposit(userId, amount) {
        console.log(`[Mock Payment] Deposit request for user ${userId}, Amount: ${amount}`);
        return { 
            success: true, 
            transactionId: "MOCK_TXN_" + Date.now(), 
            redirectUrl: "#" 
        };
    }

    async verifyWebhook(webhookData) {
        return true;
    }
}

module.exports = new PaymentService();
